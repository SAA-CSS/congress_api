<?php
/**
 * Plugin Name: Legislative data
 * Description: Go to Settings:Legislation after activation to complete the setup. Provides the shortcodes [votes] [legislation] [committee_nominations] and [committee_legislation] 
 * Version: 1.0.8
 * Author: Alterion
 */
 

// Define constants for the update server and plugin slug
define('PLUGIN_UPDATE_URL', 'https://raw.githubusercontent.com/SAA-CSS/congress_api/main/update.json');
define('PLUGIN_SLUG', 'legislative-data/legislative-data.php'); 

// Hook into the 'pre_set_site_transient_update_plugins' filter
add_filter('pre_set_site_transient_update_plugins', 'check_for_plugin_update');

if (!function_exists('check_for_plugin_update')) {
    function check_for_plugin_update($transient) {
        // Debugging information
        error_log('Checking for plugin update...');

        // Get the current version
        $current_version = '1.0.8';

        // Get the update data from the server
        $response = wp_remote_get(PLUGIN_UPDATE_URL);
        if (is_wp_error($response)) {
            error_log('Error fetching update data: ' . $response->get_error_message());
            return $transient;
        }

        $update_data = wp_remote_retrieve_body($response);
        if (empty($update_data)) {
            error_log('Update data is empty.');
            return $transient;
        }

        $update_data = json_decode($update_data, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('Error decoding JSON: ' . json_last_error_msg());
            return $transient;
        }

        if (empty($update_data['version']) || empty($update_data['download_url'])) {
            error_log('Update data is missing required fields.');
            return $transient;
        }

        // Check if a new version is available
        if (version_compare($current_version, $update_data['version'], '<')) {
            $obj = new stdClass();
            $obj->slug = PLUGIN_SLUG;
            $obj->new_version = $update_data['version'];
            $obj->url = 'https://example.com'; // URL to your plugin page
            $obj->package = $update_data['download_url'];
            $transient->response[PLUGIN_SLUG] = $obj;

            // Debugging information
            error_log('New version available: ' . $update_data['version']);
        } else {
            // Debugging information
            error_log('No new version available. Current version: ' . $current_version . ', Latest version: ' . $update_data['version']);
        }

        return $transient;
    }
}

// Hook into the 'plugins_api' filter to provide information about the update
add_filter('plugins_api', 'plugin_update_info', 10, 3);

if (!function_exists('plugin_update_info')) {
    function plugin_update_info($res, $action, $args) {
        // Ensure it's our plugin being requested
        if ($action !== 'plugin_information' || $args->slug !== 'legislative-data') {
            return false;
        }

        // Debugging information
        error_log('Providing plugin update information...');

        // Get the update data from the server
        $response = wp_remote_get(PLUGIN_UPDATE_URL);
        if (is_wp_error($response)) {
            error_log('Error fetching update data: ' . $response->get_error_message());
            return false;
        }

        $update_data = wp_remote_retrieve_body($response);
        if (empty($update_data)) {
            error_log('Update data is empty.');
            return false;
        }

        $update_data = json_decode($update_data, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('Error decoding JSON: ' . json_last_error_msg());
            return false;
        }

        if (empty($update_data['version']) || empty($update_data['download_url'])) {
            error_log('Update data is missing required fields.');
            return false;
        }

        $res = new stdClass();
        $res->name = 'Legislative Data';
        $res->slug = 'legislative-data';
        $res->version = $update_data['version'];
        $res->author = '<a href="https://example.com">Your Name</a>';
        $res->homepage = 'https://example.com';
        $res->download_link = $update_data['download_url'];
        $res->trunk = $update_data['download_url'];
        $res->requires = '5.0'; // Minimum WordPress version required
        $res->tested = '5.7'; // Tested up to WordPress version
        $res->sections = array(
            'description' => 'A custom plugin for managing legislative data updates.',
            'changelog' => $update_data['changelog']
        );

        return $res;
    }
}




// Register the admin menu
add_action('admin_menu', 'legislation_admin_menu');
function legislation_admin_menu() {
    add_options_page(
        'Legislation Settings',
        'Legislation',
        'manage_options',
        'senate-votes-settings',
        'legislation_settings_page'
    );
}

// Settings page content
function legislation_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    ?>
    <style>
        /* Admin Styles */
.wrap {
    background: #f9f9f9; /* Light background */
    border: 1px solid #e0e0e0; /* Border for the container */
    border-radius: 8px;
    padding: 20px;
    margin-top: 20px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}
.wrap tr, .wrap td{
    line-height:1.8em !important;
}
.wrap h2{
    font-size: 1.5em;
    margin-bottom: 1em;
    margin-top: 1em;
}
.nav-tab-wrapper {
    margin-bottom: 20px;
}

.nav-tab {
    padding: 10px 20px;
    font-size: 14px;
}

.nav-tab-active {
    background-color: #0073aa; /* WordPress Blue */
    color: white;
    border-radius: 4px;
}

form {
    padding: 20px;
    background: #ffffff;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}



input[type="submit"] {
    background-color: #0073aa;
    color: #ffffff;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #005177;
}
    </style>
    <div class="wrap">
        <div style="line-height:1.45em">
            <h1>Legislation Shortcodes</h1>
            <h2><strong>Installation instructions:</strong> Submit the form below then add one of the shortcodes to a page.</h2>
            <table>
            <tr>
                <td style="padding:1em; line-height:1.8em !important">
                    <h3>Shortcodes for Member (Senator) Websites:</h3>    
                    <strong>[votes]</strong> - A paginated view of the Member's voting record (source: senate.gov).<br>
                    <strong>[legislation]</strong> - A paginated view of the Member's legislative history (source: api.congress.gov).<br>
                    <strong>[congress_search_box]</strong> - A search box that queries congress.gov.
                </td>
                <td style="padding:1em; line-height:1.8em !important">
                    <h3>Shortcodes for Committee Websites:</h3>
                    <strong>[committee_nominations]</strong> - A paginated view of the committee's nomination records (source: api.congress.gov).<br>
                    <strong>[committee_legislation]</strong> - A paginated view of the committee's legislative history (source: api.congress.gov).
                </td>
            </tr>
            </table>
        </div>
        <form method="post" action="options.php">
            <?php
            settings_fields('legislation_settings_group');
            do_settings_sections('senate-votes-settings');
            submit_button();
            ?>
        </form>
        
    </div>
    <?php
}

// Register settings
add_action('admin_init', 'legislation_register_settings');
function legislation_register_settings() {
    register_setting('legislation_settings_group', 'legislation_lis_member_id');
    register_setting('legislation_settings_group', 'legislation_memberId');
    register_setting('legislation_settings_group', 'legislation_committee_code');
    register_setting('legislation_settings_group', 'congress_dot_gov_api_key'); // Register new setting

    add_settings_section('legislation_settings_section', 'Plugin Settings', null, 'senate-votes-settings');

    add_settings_field(
        'legislation_senator_select',
        'Senator',
        'legislation_senator_select_callback',
        'senate-votes-settings',
        'legislation_settings_section'
    );

    add_settings_field(
        'legislation_committee_code',
        'Committee Code',
        'legislation_committee_code_callback',
        'senate-votes-settings',
        'legislation_settings_section'
    );

    add_settings_field(
        'congress_dot_gov_api_key_field', // Field ID
        'Congress.gov API Key', // Field Title
        'congress_dot_gov_api_key_callback', // Callback Function
        'senate-votes-settings', // Page
        'legislation_settings_section' // Section
    );
}

// Callback function to display the api key field
function congress_dot_gov_api_key_callback() {
    $api_key = congress_dot_gov_api_key();
    echo '<input type="password" id="congress_dot_gov_api_key" name="congress_dot_gov_api_key" value="' . esc_attr($api_key) . '" /> <br><small>Get your API key here: <a href="https://api.congress.gov/sign-up/" target="_blank">https://api.congress.gov/sign-up/</a></small>';
}
// Callback function to display the committee code field
function legislation_committee_code_callback() {
    $committee_code = get_option('legislation_committee_code');
    echo '<input type="text" id="legislation_committee_code" name="legislation_committee_code" value="' . esc_attr($committee_code) . '" /><br><small>(For committee websites)</small>';
}
//get the lis_member_id from the bioguide_id
function set_lis_from_bioguide_id(){
	$xml = @simplexml_load_file('https://www.senate.gov/legislative/LIS_MEMBER/cvc_member_data.xml');
	$memberId = get_option('legislation_memberId');
    $senators = [];
    foreach ($xml->senator as $senator) {
       
        if($senator->bioguideId == $memberId){
			$lis_member_id = (string) $senator['lis_member_id'];
			$api_key = congress_dot_gov_api_key();
			update_option( 'legislation_lis_member_id', $lis_member_id );
			update_option( 'congress_dot_gov_api_key', $api_key );
		}
        
       
    }
}
//display congress.gov search box
function display_congress_search_box_shortcode() {
    ob_start();
    ?>
    <div class="legislation-search-form-wrapper">
        <form method="GET" action="https://www.congress.gov/search" target="_blank" class="legislation-search-form">
            <label for="congress-search-input">Search:</label>
            <input type="hidden" name="q" value='{"source":"legislation"}'>
            <input type="text" id="congress-search-input" name="search" placeholder="Congress.gov search" required>
            <input type="submit" value="Search">
        </form>
    </div>
    <?php
    return ob_get_clean();
}

// Register the shortcode
function register_congress_search_box_shortcode() {
    add_shortcode('congress_search_box', 'display_congress_search_box_shortcode');
}
add_action('init', 'register_congress_search_box_shortcode');




// Senator select field callback
function legislation_senator_select_callback() {
    $xml = @simplexml_load_file('https://www.senate.gov/legislative/LIS_MEMBER/cvc_member_data.xml');
    if ($xml === false) {
        echo 'Error loading XML file.';
        foreach (libxml_get_errors() as $error) {
            echo "<br>", htmlentities($error->message);
        }
        return;
    }

    $senators = [];
    foreach ($xml->senator as $senator) {
        $lis_member_id = (string) $senator['lis_member_id'];
        $memberId = (string) $senator->bioguideId;
        $first_name = (string) $senator->name->first;
        $last_name = (string) $senator->name->last;
        $full_name = "$last_name, $first_name";
        $senators[] = [
            'lis_member_id' => $lis_member_id,
            'memberId' => $memberId,
            'full_name' => $full_name
        ];
    }

    // Sort senators by full_name
    usort($senators, function ($a, $b) {
        return strcmp($a['full_name'], $b['full_name']);
    });

    echo '<select name="legislation_lis_member_id">';
    foreach ($senators as $senator) {
        $lis_member_id = $senator['lis_member_id'];
        $memberId = $senator['memberId'];
        $full_name = $senator['full_name'];
        $selected = (get_option('legislation_lis_member_id') == $lis_member_id) ? 'selected' : '';
        echo "<option value='$lis_member_id' data-member-id='$memberId' $selected>$full_name</option>";
    }
    echo '</select><br><small>(For member websites)</small>';
    echo '<input type="hidden" id="legislation_memberId" name="legislation_memberId" value="' . get_option('legislation_memberId') . '" />';
	
}

// Update hidden LIS Member ID input when bioguide ID select box changes
add_action('admin_footer', 'legislation_admin_footer_script');
function legislation_admin_footer_script() {
    ?>
    <script>
        document.querySelector('select[name="legislation_lis_member_id"]').addEventListener('change', function () {
            var selectedOption = this.options[this.selectedIndex];
            document.getElementById('legislation_memberId').value = selectedOption.getAttribute('data-member-id');
        });
    </script>
    <?php
}

//Return the api.congress.gov key
function congress_dot_gov_api_key() {
	$congress_dot_gov_api_key = get_option('congress_dot_gov_api_key');
	return $congress_dot_gov_api_key;
}

// Function to get member terms
function get_member_terms() {
    $memberId = get_option('legislation_memberId');  
    $congress_api_key = congress_dot_gov_api_key(); 
    $url = "https://api.congress.gov/v3/member/$memberId?format=json&API_KEY=$congress_api_key";
    $response = wp_remote_get($url);
    if (is_wp_error($response)) {
        return [];
    }
    $data = json_decode(wp_remote_retrieve_body($response), true);
    $member = $data['member'];
    $member_terms = $member['terms'];
    return $member_terms; 
}

// Enqueue plugin styles
add_action('wp_enqueue_scripts', 'legislation_enqueue_styles');
function legislation_enqueue_styles() {
    wp_enqueue_style('legislation-votes-style', plugins_url('style.css', __FILE__));
}


// Register the [votes] shortcode
add_shortcode('votes', 'display_senate_votes');

/**
 * Check if a vote menu XML file is valid for the given congress and session.
 *
 * Requirements:
 *   1. The file at https://www.senate.gov/legislative/LIS/roll_call_lists/vote_menu_{congress}_{session}.xml
 *      must exist (HTTP 200).
 *   2. The root XML <vote_summary> must contain <congress> == $congress and <session> == $session.
 *
 * @param int $congress
 * @param int $session
 * @return bool
 */

function is_valid_congress_session($congress, $session) {
    $url = "https://www.senate.gov/legislative/LIS/roll_call_lists/vote_menu_{$congress}_{$session}.xml";

    // Fetch the file headers first
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    $header_result = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    // If file not found or error, it's not valid
    if ($http_code !== 200) {
        return false;
    }

    // Now actually get the XML contents to confirm <congress> and <session>
    $xml_content = @file_get_contents($url);
    if ($xml_content === false) {
        return false;
    }

    // Parse the XML
    libxml_use_internal_errors(true);
    $xml_obj = @simplexml_load_string($xml_content);
    if (!$xml_obj) {
        return false;
    }

    // Ensure the root or near-root structure is what we expect
    // The Senate typically has a <vote_summary> root with <congress> and <session> children
    if (!isset($xml_obj->congress) || !isset($xml_obj->session)) {
        return false;
    }

    $file_congress = (int) $xml_obj->congress;
    $file_session  = (int) $xml_obj->session;

    // Must match exactly
    return ($file_congress === (int) $congress && $file_session === (int) $session);
}

/**
 * [votes] shortcode callback function
 */
function display_senate_votes() {
    ob_start();

    $lis_member_id = get_option('legislation_lis_member_id');
    $memberId = get_option('legislation_memberId');

    // Make sure we have a valid Senator's LIS ID or try to set it.
    if (!$lis_member_id) {
        if (!$memberId) {
            echo '<p>Please select a Senator in the plugin settings.</p>';
        } else {
            set_lis_from_bioguide_id();
        }
        return ob_get_clean();
    }

    // Retrieve all terms for the currently selected Senator
    $terms = get_member_terms();
    if (empty($terms)) {
        echo '<p>No terms found for the selected Senator.</p>';
        return ob_get_clean();
    }

    // Sort the terms by startYear descending
    usort($terms, function ($a, $b) {
        return $b['startYear'] - $a['startYear'];
    });

    // If today's date is January 1–6, set current_year to previous year 
	
	// Real behavior
	$current_year = (int) date("Y");
	if (date("m") == 1 && date("d") <= 6) {
		$current_year--;
	}
	//var_dump($current_year);
	

    // Build an array of valid years => ['congress' => X, 'session' => X]
    // We only add a year if is_valid_congress_session($congress, $session) returns true.
    $valid_years = []; // e.g. [2024 => ['congress' => 118, 'session' => 2], 2025 => [...], etc.]

    foreach ($terms as $term) {
        if ($term['chamber'] !== 'Senate') {
            continue;
        }

        $startYear = $term['startYear'];      // Session 1
        $startYearPlusOne = $startYear + 1;   // Session 2
        $congress = $term['congress'];

        // Check Session 1 XML
        if (is_valid_congress_session($congress, 1)) {
            $valid_years[$startYear] = [
                'congress' => $congress,
                'session'  => 1,
            ];
        }

        // Check Session 2 XML
        if (is_valid_congress_session($congress, 2)) {
            $valid_years[$startYearPlusOne] = [
                'congress' => $congress,
                'session'  => 2,
            ];
        }
    }

    // Sort the valid_years in descending order by the array key (the year)
    krsort($valid_years);

    // Determine the selected year:
    // 1. If user has chosen a year via GET, use that if it’s in $valid_years.
    // 2. Otherwise, if current_year is valid, pick that.
    // 3. Otherwise pick the most recent valid year (the first key in $valid_years).
    $selected_year = isset($_GET['vote_year']) ? (int)$_GET['vote_year'] : null;

    if ($selected_year && !isset($valid_years[$selected_year])) {
        // The user-supplied year is not valid; ignore it
        $selected_year = null;
    }

    if (!$selected_year) {
        if (isset($valid_years[$current_year])) {
            $selected_year = $current_year;
        } elseif (!empty($valid_years)) {
            // default to the first (most recent) valid year in descending order
            $selected_year = array_key_first($valid_years);
        }
    }

    // If after all that, we still have no selected year, it means no valid data
    if (!$selected_year) {
        echo '<p>No valid vote data found for this Senator.</p>';
        return ob_get_clean();
    }

    // Pull the congress and session from our validated array
    $congress_number = $valid_years[$selected_year]['congress'];
    $session         = $valid_years[$selected_year]['session'];

    // Build the drop-down select box
    echo '<div class="legislation-votes-form-wrapper">';
    echo '<form method="get" class="legislation-votes-form">';
    echo '<label for="vote_year">Year: </label>';
    echo '<select name="vote_year" id="vote_year" onchange="this.form.submit()">';

    foreach ($valid_years as $year => $info) {
        $display_congress = $info['congress'];
        $display_session  = $info['session'];
        $selected_attr    = ($year == $selected_year) ? ' selected' : '';
        echo '<option value="' . $year . '"' . $selected_attr . '>';
        echo $year . ' (Congress ' . $display_congress . ' Session ' . $display_session . ')';
        echo '</option>';
    }

    echo '</select>';
    echo '</form>';
    echo '</div>';

    // ----------------------------------------------------------------------
    // NOW LOAD AND DISPLAY THE VOTES FOR THE SELECTED YEAR
    // ----------------------------------------------------------------------
    $vote_page     = isset($_GET['vote_page']) ? (int)$_GET['vote_page'] : 1;
    $votes_per_page = 10;

    $menu_url = "https://www.senate.gov/legislative/LIS/roll_call_lists/vote_menu_{$congress_number}_{$session}.xml";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $menu_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_FAILONERROR, true);
    $menu_xml_content = curl_exec($ch);
    curl_close($ch);

    // If something goes wrong now, there's probably a transient issue
    if ($menu_xml_content === false) {
        echo 'Error loading votes menu XML file: ' . htmlentities($menu_url) . '<br>';
        return ob_get_clean();
    }

    // Parse the votes menu
    libxml_use_internal_errors(true);
    $menu_xml = @simplexml_load_string($menu_xml_content);
    if ($menu_xml === false) {
        echo 'Error parsing votes menu XML file: ' . htmlentities($menu_url) . '<br>';
        foreach (libxml_get_errors() as $error) {
            echo htmlentities($error->message) . '<br>';
        }
        return ob_get_clean();
    }

    // Collect the votes in a paginated manner
    $total_votes = count($menu_xml->votes->vote);
    $offset      = ($vote_page - 1) * $votes_per_page;
    $end         = $offset + $votes_per_page;

    $votes = [];
    for ($i = $offset; $i < $end && $i < $total_votes; $i++) {
        $vote = $menu_xml->votes->vote[$i];
        $vote_number = (string) $vote->vote_number;
        $vote_date   = (string) $vote->vote_date;

        // Convert the date to mm-dd-yyyy using the selected year as a fallback
        $vote_date = date('m-d-Y', strtotime($vote_date . ' ' . $selected_year));
        $title     = (string) $vote->title;
        $question  = (string) $vote->question;
        $result    = (string) $vote->result;
        $yeas      = (int) $vote->vote_tally->yeas;
        $nays      = (int) $vote->vote_tally->nays;

        $summary_html = "https://www.senate.gov/legislative/LIS/roll_call_votes/vote{$congress_number}{$session}/vote_{$congress_number}_{$session}_$vote_number.htm";
        $vote_url     = "https://www.senate.gov/legislative/LIS/roll_call_votes/vote{$congress_number}{$session}/vote_{$congress_number}_{$session}_$vote_number.xml";

        // Load the full vote details to see how our Senator voted
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $vote_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, true);
        $vote_xml_content = curl_exec($ch);
        curl_close($ch);

        if ($vote_xml_content === false) {
            continue; // skip if not accessible
        }

        libxml_use_internal_errors(true);
        $vote_xml = @simplexml_load_string($vote_xml_content);
        if ($vote_xml === false) {
            continue; // skip if parse fails
        }

        // Find our Senator's vote
        $my_vote = 'N/A';
        foreach ($vote_xml->members->member as $member) {
            if ((string) $member->lis_member_id == $lis_member_id) {
                $my_vote = (string) $member->vote_cast;
                break;
            }
        }

        $votes[] = [
            'date'         => $vote_date,
            'description'  => $title,
            'question'     => $question,
            'result'       => $result,
            'yeas'         => $yeas,
            'nays'         => $nays,
            'my_vote'      => $my_vote,
            'summary_html' => $summary_html
        ];
    }

    // ----------------------------------------------------------------------
// DISPLAY THE VOTES TABLE (Desktop / Wide Screens)
// ----------------------------------------------------------------------
echo '<div class="vote_table_wrapper desktop-view"><br>
      <table class="vote_table">
        <tr>
          <th class="legislation_table_th vote_date_th">Vote&nbsp;Date</th>
          <th class="legislation_table_th vote_description_th">Description</th>
          <th class="legislation_table_th vote_myvote_th">My&nbsp;Vote</th>
          <th class="legislation_table_th vote_result_th">Vote&nbsp;Result</th>
        </tr>';

foreach ($votes as $vote) {
    $vote_tally = $vote['yeas'] + $vote['nays'];
    $yeas_percentage = ($vote_tally > 0) ? round(($vote['yeas'] / $vote_tally) * 100, 2) : 0;
    $nays_percentage = 100 - $yeas_percentage;

    echo '<tr>
            <td class="vote_date_column"><span class="legislation_date">' . htmlentities($vote['date']) . '</span></td>
            <td class="vote_detail">
              <div class="vote_question">' . htmlspecialchars($vote['question']) . '</div>
              <div class="vote_title">' . htmlspecialchars($vote['description']) . '</div>
              <div class="vote_link"><a href="' . htmlspecialchars($vote['summary_html']) . '" target="_blank">Vote Details</a></div>
            </td>
            <td class="vote_position">' . htmlspecialchars($vote['my_vote']) . '</td>
            <td class="vote_result_column">
              <div class="vote_result">' . htmlspecialchars($vote['result']) . '</div>
              <div class="vote_yeanay">(Y:' . htmlspecialchars($vote['yeas']) . ' N:' . htmlspecialchars($vote['nays']) . ')</div>
              <div class="vote_tally_container">
                <div class="vote_tally_yeas" style="width:' . $yeas_percentage . '%;"></div>
                <div class="vote_tally_nays" style="width:' . $nays_percentage . '%;"></div>
              </div>
            </td>
          </tr>';
}

echo '</table>
      </div>';


// ----------------------------------------------------------------------
// DISPLAY THE VOTES AS CARDS (Mobile View)
// ----------------------------------------------------------------------
echo '<div class="vote_cards_container mobile-view">';

foreach ($votes as $vote) {
    $vote_tally = $vote['yeas'] + $vote['nays'];
    $yeas_percentage = ($vote_tally > 0) ? round(($vote['yeas'] / $vote_tally) * 100, 2) : 0;
    $nays_percentage = 100 - $yeas_percentage;
	$pretty_date = date("F jS, Y", strtotime($vote['date']));
    echo '<div class="vote_card">
            <div class="vote_card_row">
              <label>' . htmlentities($vote['date']) . '</label>
              
            </div>
            
            <div class="vote_card_row">
              
              <div>
                <div class="vote_question">' . htmlspecialchars($vote['question']) . '</div>
                <div class="vote_title">' . htmlspecialchars($vote['description']) . '</div>
                
              </div>
            </div>
            
            <div class="vote_card_row">
              <label>My Vote: <span style="font-weight:normal">' . htmlspecialchars($vote['my_vote']) . '</span></label>
              
            </div>
            
            <div class="vote_card_row">
              <label>Result: <span style="font-weight:normal">' . htmlspecialchars($vote['result']) . ' (Y:' . htmlspecialchars($vote['yeas']) . ' N:' . htmlspecialchars($vote['nays']) . ')</span></label>
			  
              <div style="display:none">
                <div class="vote_result"></div>
                <div class="vote_yeanay">(Y:' . htmlspecialchars($vote['yeas']) . ' N:' . htmlspecialchars($vote['nays']) . ')</div>
                <div class="vote_tally_container">
                  <div class="vote_tally_yeas" style="width:' . $yeas_percentage . '%;"></div>
                  <div class="vote_tally_nays" style="width:' . $nays_percentage . '%;"></div>
                </div>
              </div>
            </div>
			<div class="vote_card_row">
			<a href="' . htmlspecialchars($vote['summary_html']) . '" target="_blank"><button class="vote_card_button">Vote Details</button></a>
			</div>
          </div>';
}

echo '</div>';

    // ----------------------------------------------------------------------
    // PAGINATION
    // ----------------------------------------------------------------------
    $total_pages       = ceil($total_votes / $votes_per_page);
    $max_display_pages = 5; // how many page links to show near current

    if ($total_pages > 1) {
        echo '<div class="votes_pagination_container">';

        // Previous link
        if ($vote_page > 1) {
            $prevpage = $vote_page - 1;
            echo '<span class="page_prev vote_page_prev"><a href="?vote_year=' . $selected_year . '&vote_page=' . $prevpage . '">&#171;</a></span>';
        }

        // Special case: first page
        if ($vote_page == 1) {
            echo '<span class="votes_page_number votes_page_number_active">1</span>';
            for ($i = 2; $i <= min(3, $total_pages); $i++) {
                echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=' . $i . '">' . $i . '</a></span>';
            }
            if ($total_pages > 3) {
                echo '<span class="ellipsis">...</span>';
                echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=' . $total_pages . '">' . $total_pages . '</a></span>';
            }
        }
        // Special case: last page
        elseif ($vote_page == $total_pages) {
            if ($total_pages > 3) {
                echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=1">1</a></span>';
                echo '<span class="ellipsis">...</span>';
            }
            for ($i = max(1, $total_pages - 2); $i < $total_pages; $i++) {
                echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=' . $i . '">' . $i . '</a></span>';
            }
            echo '<span class="votes_page_number votes_page_number_active">' . $total_pages . '</span>';
        }
        // General middle page
        else {
            // Show first page
            echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=1">1</a></span>';
            if ($vote_page > 4) {
                echo '<span class="ellipsis">...</span>';
            }

            // Range around current
            $start = max(2, $vote_page - 2);
            $end   = min($total_pages - 1, $vote_page + 2);

            for ($i = $start; $i <= $end; $i++) {
                if ($i == $vote_page) {
                    echo '<span class="votes_page_number votes_page_number_active">' . $i . '</span>';
                } else {
                    echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=' . $i . '">' . $i . '</a></span>';
                }
            }

            if ($vote_page < $total_pages - 3) {
                echo '<span class="ellipsis">...</span>';
            }
            // Show last page
            echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=' . $total_pages . '">' . $total_pages . '</a></span>';
        }

        // Next link
        if ($vote_page < $total_pages) {
            $nextpage = $vote_page + 1;
            echo '<span class="page_next vote_page_next"><a href="?vote_year=' . $selected_year . '&vote_page=' . $nextpage . '">&#187;</a></span>';
        }

        echo '</div>';
    }

    return ob_get_clean();
}
// Fetch data with error handling
function fetchData($url) {
    if (empty($url)) {
        die("Error: URL is empty.");
    }

    // Append the API key to the URL
    $urlWithKey = $url . (strpos($url, '?') === false ? '?' : '&') . 'api_key=' . API_KEY;

    $context = stream_context_create([
        'http' => [
            'header' => "User-Agent: MyCustomAgent/1.0 PHP\r\n"
        ]
    ]);

    $response = @file_get_contents($urlWithKey, false, $context);
    if ($response === false) {
        error_log("Error fetching data from $urlWithKey");
        return null; // Return null to gracefully handle failures
    }

    $data = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log("JSON decoding error: " . json_last_error_msg());
        return null;
    }
    return $data;
}

// Build Congress.gov URL
function buildCongressGovUrl($congress, $type, $number) {
    switch ($type) {
        case 'HR':
            $chamber = 'house-bill';
            break;
        case 'S':
            $chamber = 'senate-bill';
            break;
        case 'HRES':
            $chamber = 'house-resolution';
            break;
        case 'SRES':
            $chamber = 'senate-resolution';
            break;
        case 'HJRES':
            $chamber = 'house-joint-resolution';
            break;
        case 'SJRES':
            $chamber = 'senate-joint-resolution';
            break;
        case 'HCONRES':
            $chamber = 'house-concurrent-resolution';
            break;
        case 'SCONRES':
            $chamber = 'senate-concurrent-resolution';
            break;
        default:
            $chamber = 'unknown-type'; // Fallback for debugging
    }
    return "https://www.congress.gov/bill/{$congress}th-congress/{$chamber}/{$number}";
}

 // Function to fetch update date from bill detail endpoint
function fetch_update_date($url) {
    $congress_api_key = congress_dot_gov_api_key();
    $url = remove_format_xml($url);
    $response = wp_remote_get($url . '?format=json&api_key=' . $congress_api_key);
    if (is_wp_error($response)) {
        return null;
    }
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    return isset($data['bill']['updateDate']) ? $data['bill']['updateDate'] : null;
}
// Function to format the date to mm-dd-yyyy
function format_date($date) {
    if (!$date) {
        return '';
    }
    $timestamp = strtotime($date);
    return date('m-d-Y', $timestamp);
}
function remove_format_xml($url) {
    // Check if the URL ends with '?format=xml'
    if (substr($url, -11) === '?format=xml') {
        // Remove '?format=xml' from the end of the URL
        $clean_url = substr($url, 0, -11);
    } else {
        // If it doesn't end with '?format=xml', return the original URL
        $clean_url = $url;
    }

    return $clean_url;
}


// Function to generate the correct Congress.gov URL
function generate_congress_gov_url($congress, $type, $number) {
    switch ($type) {
    case 'HR':
        $chamber = 'house-bill';
        break;
    case 'S':
        $chamber = 'senate-bill';
        break;
    case 'HRES':
        $chamber = 'house-resolution';
        break;
    case 'SRES':
        $chamber = 'senate-resolution';
        break;
    case 'HJRES':
        $chamber = 'house-joint-resolution';
        break;
    case 'SJRES':
        $chamber = 'senate-joint-resolution';
        break;
    case 'HCONRES':
        $chamber = 'house-concurrent-resolution';
        break;
    case 'SCONRES':
        $chamber = 'senate-concurrent-resolution';
        break;
    default:
        $chamber = 'unknown-type'; // Fallback for debugging
}

    return "https://www.congress.gov/bill/{$congress}th-congress/{$chamber}/{$number}";
}

//check if sponsored legislation is empty for a given memberId
function isSponsoredLegislationEmpty($memberId, $congress_api_key) {
    $api_url = "https://api.congress.gov/v3/member/$memberId/sponsored-legislation?format=json&api_key=$congress_api_key&limit=1";

    // Fetch the data
    $response = wp_remote_get($api_url);

    if (is_wp_error($response)) {
        return false; // Assume false to prevent blocking functionality due to API failure
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    // Check if the sponsoredLegislation key exists and contains records
    return !isset($data['sponsoredLegislation']) || empty($data['sponsoredLegislation']);
}


// Register the [legislation] shortcode
add_shortcode('legislation', 'display_legislation');

// [legislation] shortcode callback function
function display_legislation() {
    ob_start();

    $lis_member_id = get_option('legislation_lis_member_id');
    $memberId = get_option('legislation_memberId');

    if (!$lis_member_id) {
		if (!$memberId) {
        echo '<p>Please select a Senator in the plugin settings.</p>';
		} else {
			set_lis_from_bioguide_id();
		}
        return ob_get_clean();
    }

    $congress_api_key = congress_dot_gov_api_key();
    $leg_type = isset($_GET['leg_type']) ? $_GET['leg_type'] : 'sponsored';
    $sponsored_empty = isSponsoredLegislationEmpty($memberId, $congress_api_key);
    if ($sponsored_empty) {
        $leg_type = 'cosponsored';
        $leg_form_class = 'hide-legislation-element';
    } else {
        $leg_form_class = '';
    }
    $page = isset($_GET['leg_page']) ? (int)$_GET['leg_page'] : 1;
    $items_per_page = 20;
    $offset = ($page - 1) * $items_per_page;

   

    // Determine the endpoint based on the selected type
    $endpoint = $leg_type === 'cosponsored' ? 'cosponsored-legislation' : 'sponsored-legislation';
    $api_url = "https://api.congress.gov/v3/member/$memberId/$endpoint?format=json&api_key=$congress_api_key&limit=$items_per_page&offset=$offset";

    // Fetch legislation data
    $response = wp_remote_get($api_url);
    if (is_wp_error($response)) {
        echo '<p>Error fetching legislation data.</p>';
        echo '<p>' . $response->get_error_message() . '</p>';
        return ob_get_clean();
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    if (!$data || (!isset($data['sponsoredLegislation']) && !isset($data['cosponsoredLegislation']))) {
        echo '<p>No legislation data found.</p>';
        echo '<!-- Debugging: ' . htmlentities($body) . ' -->';
        return ob_get_clean();
    }

    

    // Extract the relevant data
    $legislation_data = isset($data['sponsoredLegislation']) ? $data['sponsoredLegislation'] : $data['cosponsoredLegislation'];

    

    // Extract pagination info
    $total_items = $data['pagination']['count'];
    $total_pages = ceil($total_items / $items_per_page);

    // Filter and sort the data by latest activity date
    $filtered_data = array_filter($legislation_data, function($item) {
        return $item['type'] !== '';
    });

    // Fetch update dates and sort by update date
    foreach ($filtered_data as &$item) {
        $update_date = fetch_update_date($item['url']);
        $item['updateDate'] = $update_date;
    }
    unset($item); // Break reference to the last element

    usort($filtered_data, function ($a, $b) {
        return strtotime($b['updateDate']) - strtotime($a['updateDate']);
    });


   
    // Display the form for toggling between Sponsored and Cosponsored legislation
    echo '<div class="legislation-votes-form-wrapper '. $leg_form_class . '">';
    echo '<form method="get" id="legislation-toggle-form" class="legislation-votes-form">';
    echo '<label>Type: </label>';
    echo '<select name="leg_type" onchange="this.form.submit()">';
    echo '<option value="sponsored"' . ($leg_type === 'sponsored' ? ' selected' : '') . '>Sponsored legislation</option>';
    echo '<option value="cosponsored"' . ($leg_type === 'cosponsored' ? ' selected' : '') . '>Cosponsored legislation</option>';
    echo '</select>';
    echo '</form>';
    echo '</div>';

    // Display the table
    echo '<table class="legislation-table">';
    echo '
	<thead>
	<tr>
	<th class="legislation_table_th legislation_update_th">Updated</th>
	<th class="legislation_table_th legislation_overview_th">Bill Information</th>
	<th class="legislation_table_th legislation_link_th">Detail</th>
	</tr>
	</thead>';
    echo '<tbody>';
    foreach ($filtered_data as $item) {
		$detail_url = $item['url'] . '&api_key=' . $congress_api_key;
		$introduced_date = $item['introducedDate'];
		if(isset($item['title']) && $item['title'] != ""){
        	$title = $item['title'];
			$bill_type = $item['type'];
			$number = $item['number'];
			
			$latest_action_text = isset($item['latestAction']['text']) ? $item['latestAction']['text'] : '';
			$congress_gov_url = generate_congress_gov_url($item['congress'], $bill_type, $number);
			$update_date = isset($item['updateDate']) ? $item['updateDate'] : '';
        
        
		} else {
			$response_detail = wp_remote_get($detail_url);
			$body_detail = wp_remote_retrieve_body($response_detail);
			$data_detail = json_decode($body_detail, true);
			
				//$title = $item_detail['title'];
			if (isset($data_detail['amendment'])) {
				if (isset($data_detail['amendment']['number'])) {
					$amendmentNumber = $data_detail['amendment']['number'];
					$latest_action_text = 'Amendment ' . $amendmentNumber; 
				}
				if (isset($data_detail['amendment']['actions']['url'])) {
					$actionsUrl = $data_detail['amendment']['actions']['url'];
				}
				if (isset($data_detail['amendment']['amendedBill'])) {
					if (isset($data_detail['amendment']['amendedBill']['number'])) {
						$number = $data_detail['amendment']['amendedBill']['number'];
					}
					if (isset($data_detail['amendment']['amendedBill']['type'])) {
						$bill_type = $data_detail['amendment']['amendedBill']['type'];
					}
					if (isset($data_detail['amendment']['amendedBill']['congress'])) {
						$congress = $data_detail['amendment']['amendedBill']['congress'];
					}
					if (isset($data_detail['amendment']['amendedBill']['title'])) {
						$title = $data_detail['amendment']['amendedBill']['title'];
					}
					$congress_gov_url = generate_congress_gov_url($congress, $bill_type, $number);
				}
				if (isset($data_detail['amendment']['updateDate'])) {
					$updateDate = $data_detail['amendment']['updateDate'];
				}
				
			}
			
		}
        
        $formatted_update_date = format_date($update_date);

        echo '<tr>';
        echo '<td class="legislation_update_column">';
		echo '<div class="legislation_update_date legislation_date">' . esc_html($formatted_update_date) . '</div>';
		echo '</td>';
		
        echo '<td  class="legislation_title_column">';
		
		echo '<div class="legislation_title"><em><strong><a href="' . esc_url($congress_gov_url) . '" target="_blank">' . esc_html($bill_type . '.' . $number) . '</em></a> | ' . esc_html($title) . '</strong></div>';
		//echo '<div class="legislation_introduced_date"><em>Introduced:</em> <span class="legislation_date">' . esc_html(format_date($introduced_date)) . '</span></div>';
		echo '<div class="legislation_latest_action"><em>Latest Action: ' . esc_html($latest_action_text) . '</em></div>';
		echo '</td>';
        echo '<td class="legislation_link_column">';
		echo '<div class="legislation_link"><a href="' . esc_url($congress_gov_url) . '" target="_blank">Detail</a></div>';
		
		echo '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';

    // Pagination links
    if ($total_pages > 1) {
        echo '<div class="votes_pagination_container">';
        if ($page > 1) {
            $prev_page = $page - 1;
            echo '<span class="page_prev vote_page_prev"><a href="?leg_type=' . $leg_type . '&leg_page=' . $prev_page . '">&laquo;</a></span>';
        }

        $range = 2;
        $start = max(1, $page - $range);
        $end = min($total_pages, $page + $range);

        if ($start > 1) {
            echo '<span class="votes_page_number"><a href="?leg_type=' . $leg_type . '&leg_page=1">1</a></span>';
            if ($start > 2) {
                echo '<span class="ellipsis">...</span>';
            }
        }

        for ($i = $start; $i <= $end; $i++) {
            if ($i == $page) {
                echo '<span class="votes_page_number votes_page_number_active">' . $i . '</span>';
            } else {
                echo '<span class="votes_page_number"><a href="?leg_type=' . $leg_type . '&leg_page=' . $i . '">' . $i . '</a></span>';
            }
        }

        if ($end < $total_pages) {
            if ($end < $total_pages - 1) {
                echo '<span class="ellipsis">...</span>';
            }
            echo '<span class="votes_page_number"><a href="?leg_type=' . $leg_type . '&leg_page=' . $total_pages . '">' . $total_pages . '</a></span>';
        }

        if ($page < $total_pages) {
            $next_page = $page + 1;
            echo '<span class="page_next vote_page_next"><a href="?leg_type=' . $leg_type . '&leg_page=' . $next_page . '">&raquo;</a></span>';
        }
        echo '</div>';
    }

    return ob_get_clean();
}



//Committee legislation functions

// Register the [committee_legislation] shortcode
add_shortcode('committee_legislation', 'display_committee_bills');
/********************************************************
 * Helper: Append ?format=json&api_key= if missing
 ********************************************************/
function ensure_format_and_api_key($url, $api_key) {
    // Check if the URL already has a query string
    $hasQuery = (strpos($url, '?') !== false);

    // We'll build a small string to append
    //   if '?' isn't in $url, we start with '?'
    //   otherwise we use '&'
    $separator = $hasQuery ? '&' : '?';

    // If you want to be absolutely sure not to duplicate, you can do extra checks:
    // For simplicity, we'll just always append if not found.
    if (stripos($url, 'format=json') === false) {
        $url .= $separator . 'format=json';
        $separator = '&';
    }

    if (stripos($url, 'api_key=') === false) {
        $url .= $separator . 'api_key=' . urlencode($api_key);
    }

    return $url;
}

/**************************************
 * Helper: Fetch JSON from a given URL
 **************************************/
function committee_fetch_json($url) {
    $response = @file_get_contents($url);
    if ($response === false) {
        return null;
    }
    $data = @json_decode($response, true);
    if (!is_array($data)) {
        return null;
    }
    return $data;
}

/************************************************************
 * Truncated Pagination Function
 ************************************************************/
function committee_display_truncated_pagination($currentPage, $totalPages, $selectedYear, $maxShow = 5) {
    if ($totalPages < 2) {
        return; // Nothing to paginate
    }

    echo '<div class="bills_pagination_container">';

    // Previous link
    if ($currentPage > 1) {
        $prev = $currentPage - 1;
        echo '<span class="committee_page_prev"><a href="?bill_year=' . urlencode($selectedYear) . '&bill_page=' . $prev . '">&#171;</a></span>';
    }

    // If total pages is small, show them all
    if ($totalPages <= $maxShow) {
        for ($i = 1; $i <= $totalPages; $i++) {
            if ($i == $currentPage) {
                echo '<span class="committee_page_active">' . $i . '</span>';
            } else {
                echo '<span><a href="?bill_year=' . urlencode($selectedYear) . '&bill_page=' . $i . '">' . $i . '</a></span>';
            }
        }
    } else {
        // Always show page 1
        if ($currentPage == 1) {
            echo '<span class="committee_page_active">1</span>';
        } else {
            echo '<span><a href="?bill_year=' . urlencode($selectedYear) . '&bill_page=1">1</a></span>';
        }

        // Insert leading "..." if needed
        if ($currentPage > 3) {
            echo '<span class="committee_ellipsis">...</span>';
        }

        // Middle neighbors
        $start = max(2, $currentPage - 1);
        $end   = min($totalPages - 1, $currentPage + 1);

        for ($i = $start; $i <= $end; $i++) {
            if ($i == $currentPage) {
                echo '<span class="committee_page_active">' . $i . '</span>';
            } else {
                echo '<span><a href="?bill_year=' . urlencode($selectedYear) . '&bill_page=' . $i . '">' . $i . '</a></span>';
            }
        }

        // If current page < totalPages-2, show trailing "..."
        if ($currentPage < $totalPages - 2) {
            echo '<span class="committee_ellipsis">...</span>';
        }

        // Show last page
        if ($currentPage == $totalPages) {
            echo '<span class="committee_page_active">' . $totalPages . '</span>';
        } else {
            echo '<span><a href="?bill_year=' . urlencode($selectedYear) . '&bill_page=' . $totalPages . '">' . $totalPages . '</a></span>';
        }
    }

    // Next link
    if ($currentPage < $totalPages) {
        $next = $currentPage + 1;
        echo '<span class="page_next"><a href="?bill_year=' . urlencode($selectedYear) . '&bill_page=' . $next . '">&#187;</a></span>';
    }

    echo '</div>';
}

/********************************************************
 * Build committee bills URL (includes ?format=json&api_key=)
 ********************************************************/
function get_committee_bills_url($year, $offset = 0, $limit = 10) {
    $api_key = congress_dot_gov_api_key();

    // Format the fromDateTime and toDateTime (Jan 3 to Dec 31)
    $fromDate = "{$year}-01-03T00:00:00Z";
    $toDate   = "{$year}-12-31T23:59:59Z";

    $committee_code = get_option('legislation_committee_code');
	
    $base = "https://api.congress.gov/v3/committee/senate/" . $committee_code . "/bills"
          . "?offset={$offset}"
          . "&limit={$limit}"
          . "&fromDateTime={$fromDate}"
          . "&toDateTime={$toDate}";

    // Now ensure we add format=json and api_key
    // Note: base already has a '?' so we expect to append with '&'
    $url = ensure_format_and_api_key($base, $api_key);

    return $url;
}

/********************************************************
 * The main display function
 ********************************************************/
function display_committee_bills() {
    ob_start();

    // 1) Determine year and pagination
    $currentYear = (int) date("Y");
    if (date("m") == 1 && date("d") <= 6) {
        $currentYear--; 
    }

    $selectedYear = isset($_GET['bill_year']) ? (int)$_GET['bill_year'] : $currentYear;
    $page         = isset($_GET['bill_page']) ? max(1, (int)$_GET['bill_page']) : 1;
    $limit        = 10;
    $offset       = ($page - 1) * $limit;

    // 2) Generate year select (last 10 years)
    echo '<div class="legislation-votes-form-wrapper">';
    echo '<form method="GET" class="legislation-votes-form">';
    echo '<label for="bill_year">Year: </label>';
    echo '<select name="bill_year" id="bill_year" onchange="this.form.submit()">';

    for ($y = $currentYear; $y >= ($currentYear - 9); $y--) {
        // Compute congress/session for display
        $congress = floor(($y - 1789) / 2) + 1;
        $session  = ($y % 2 === 0) ? 2 : 1;

        $displayTxt = "{$y} (Congress {$congress} Session {$session})";
        $selected   = ($y == $selectedYear) ? ' selected' : '';

        echo "<option value=\"{$y}\"{$selected}>{$displayTxt}</option>";
    }

    // Reset page to 1 whenever year changes
    echo '<input type="hidden" name="page" value="1">';
    echo '</select>';
    echo '</form>';
    echo '</div>';

    // 3) Fetch committee bills data
    $baseUrl  = get_committee_bills_url($selectedYear, $offset, $limit);
    $baseData = committee_fetch_json($baseUrl);

    if (!$baseData || empty($baseData['committee-bills']['bills'])) {
        echo '<p>No bill data found for this committee in ' . htmlspecialchars($selectedYear) . '.</p>';
        return ob_get_clean();
    }

    // Pagination count
    $totalCount = !empty($baseData['pagination']['count']) ? (int)$baseData['pagination']['count'] : 0;
    $totalPages = ($totalCount > 0) ? ceil($totalCount / $limit) : 1;

    $bills = $baseData['committee-bills']['bills'];
    $results = [];

    // 4) Build detailed results
    foreach ($bills as $item) {
        // Format the date to YYYY-MM-DD
        $rawUpdateDate = isset($item['updateDate']) ? $item['updateDate'] : '';
        $formattedDate = '';
        if ($rawUpdateDate) {
            $timestamp     = strtotime($rawUpdateDate);
            $formattedDate = $timestamp ? date("Y-m-d", $timestamp) : '';
        }

        // Ensure detail url has format=json&api_key
        $api_key = congress_dot_gov_api_key();
        $detailUrl = isset($item['url']) ? ensure_format_and_api_key($item['url'], $api_key) : '';

        $title        = '';
        $sponsor      = '';
        $latestAction = '';
        $pdfLink      = '';

        if ($detailUrl) {
            $detailData = committee_fetch_json($detailUrl);
            if (!empty($detailData['bill'])) {
                $billInfo = $detailData['bill'];

                // Title
                if (!empty($billInfo['title'])) {
                    $title = $billInfo['title'];
                }

                // Sponsor (fullName from the first sponsor)
                if (!empty($billInfo['sponsors']) && is_array($billInfo['sponsors']) && !empty($billInfo['sponsors'][0]['fullName'])) {
                    $sponsor = $billInfo['sponsors'][0]['fullName'];
                }

                // Latest Action
                if (!empty($billInfo['latestAction']['text'])) {
                    $latestAction = $billInfo['latestAction']['text'];
                }

                // textVersions -> PDF link
                if (!empty($billInfo['textVersions']['url'])) {
                    $tvUrl = ensure_format_and_api_key($billInfo['textVersions']['url'], $api_key);
                    $tvData = committee_fetch_json($tvUrl);
                    if (!empty($tvData['textVersions'][0]['formats'])) {
                        foreach ($tvData['textVersions'][0]['formats'] as $fmt) {
                            if (!empty($fmt['type']) && $fmt['type'] === 'PDF') {
                                $pdfLink = $fmt['url'];
                                break;
                            }
                        }
                    }
                }
            }
        }

        $results[] = [
            'updateDate'   => $formattedDate,
            'title'        => $title,
            'sponsor'      => $sponsor,
            'latestAction' => $latestAction,
            'pdfLink'      => $pdfLink
        ];
    }

    // 5) Output Table (desktop) + Cards (mobile)
    // --- Desktop Table ---
    echo '<div class="committee_bills_table_wrapper committee_desktop_view">';
    echo '<table class="committee_bills_table">';
    echo '<tr >
            <th style="text-align:center">Updated</th>
            <th style="text-align:left">Title</th>
            <th style="text-align:center">Details</th>
          </tr>';

    foreach ($results as $row) {
        echo '<tr>
                <td class="committee_bill_date" valign="top" align="center">' . htmlspecialchars($row['updateDate']) . '</td>
                <td>
                    <div class="committee_bills_row"><strong>Title:</strong> ' . htmlspecialchars($row['title']) . '</div>
                    <div class="committee_bills_row"><strong>Sponsored by:</strong> ' . htmlspecialchars($row['sponsor']) . '</div>
                    <div class="committee_bills_row"><strong>Latest Action:</strong> ' . htmlspecialchars($row['latestAction']) . '</div>
                </td>
                <td valign="top" align="center">';
        if (!empty($row['pdfLink'])) {
            echo '<a href="' . htmlspecialchars($row['pdfLink']) . '" target="_blank">PDF</a>';
        } else {
            echo 'N/A';
        }
        echo '  </td>
              </tr>';
    }
    echo '</table>';
    echo '</div>';

    // --- Mobile Cards ---
    echo '<div class="committee_bills_cards_container committee_mobile_view">';
    foreach ($results as $row) {
        echo '<div class="committee_bills_card">
                <div class="committee_bills_card_row">
                    <label>' . htmlspecialchars($row['updateDate']) . '</label>
                    
                </div>
                <div class="committee_bills_card_row">
                    <label>Title:</label>
                    <span>' . htmlspecialchars($row['title']) . '</span>
                </div>
                <div class="committee_bills_card_row">
                    <label>Sponsored by:</label>
                    <span>' . htmlspecialchars($row['sponsor']) . '</span>
                </div>
                <div class="committee_bills_card_row">
                    <label>Latest Action:</label>
                    <span>' . htmlspecialchars($row['latestAction']) . '</span>
                </div>
                <div class="committee_bills_card_row">
                    <label>Details:</label>';
        if (!empty($row['pdfLink'])) {
            echo '<span><a href="' . htmlspecialchars($row['pdfLink']) . '" target="_blank">PDF</a></span>';
        } else {
            echo '<span>N/A</span>';
        }
        echo '  </div>
              </div>';
    }
    echo '</div>';

    // 6) Truncated Pagination
    committee_display_truncated_pagination($page, $totalPages, $selectedYear, 5);

    return ob_get_clean();
}

//committee nominations functions

// -------------------------------------
// Register Shortcode: [committee_nominations]
// -------------------------------------
add_shortcode('committee_nominations', 'display_committee_nominations');

/********************************************************
 * Helper: Append ?format=json&api_key= if missing
 ********************************************************/
function committee_nominations_ensure_format_and_api_key($url, $api_key) {
    $hasQuery = (strpos($url, '?') !== false);
    $separator = $hasQuery ? '&' : '?';

    if (stripos($url, 'format=json') === false) {
        $url .= $separator . 'format=json';
        $separator = '&';
    }
    if (stripos($url, 'api_key=') === false) {
        $url .= $separator . 'api_key=' . urlencode($api_key);
    }

    return $url;
}

/**************************************
 * Helper: Fetch JSON from a given URL
 **************************************/
function committee_nominations_fetch_json($url) {
    $response = @file_get_contents($url);
    if ($response === false) {
        return null;
    }
    $data = @json_decode($response, true);
    if (!is_array($data)) {
        return null;
    }
    return $data;
}

/************************************************************
 * Truncated Pagination Function (uses nom_page)
 ************************************************************/
function committee_nominations_display_truncated_pagination($currentPage, $totalPages, $maxShow = 5) {
    if ($totalPages < 2) {
        return; // Nothing to paginate
    }

    echo '<div class="nominations_pagination_container">';

    // Previous link
    if ($currentPage > 1) {
        $prev = $currentPage - 1;
        echo '<span class="committee_nominations_page_prev"><a href="?nom_page=' . $prev . '">&#171;</a></span>';
    }

    // If total pages is small, show them all
    if ($totalPages <= $maxShow) {
        for ($i = 1; $i <= $totalPages; $i++) {
            if ($i == $currentPage) {
                echo '<span class="committee_nominations_page_active">' . $i . '</span>';
            } else {
                echo '<span><a href="?nom_page=' . $i . '">' . $i . '</a></span>';
            }
        }
    } else {
        // Always show page 1
        if ($currentPage == 1) {
            echo '<span class="committee_nominations_page_active">1</span>';
        } else {
            echo '<span><a href="?nom_page=1">1</a></span>';
        }

        // Insert leading "..." if needed
        if ($currentPage > 3) {
            echo '<span class="committee_nominations_ellipsis">...</span>';
        }

        // Middle neighbors
        $start = max(2, $currentPage - 1);
        $end   = min($totalPages - 1, $currentPage + 1);

        for ($i = $start; $i <= $end; $i++) {
            if ($i == $currentPage) {
                echo '<span class="committee_nominations_page_active">' . $i . '</span>';
            } else {
                echo '<span><a href="?nom_page=' . $i . '">' . $i . '</a></span>';
            }
        }

        // If current page < totalPages-2, show trailing "..."
        if ($currentPage < $totalPages - 2) {
            echo '<span class="committee_nominations_ellipsis">...</span>';
        }

        // Show last page
        if ($currentPage == $totalPages) {
            echo '<span class="committee_nominations_page_active">' . $totalPages . '</span>';
        } else {
            echo '<span><a href="?nom_page=' . $totalPages . '">' . $totalPages . '</a></span>';
        }
    }

    // Next link
    if ($currentPage < $totalPages) {
        $next = $currentPage + 1;
        echo '<span class="committee_nominations_page_next"><a href="?nom_page=' . $next . '">&#187;</a></span>';
    }

    echo '</div>';
}

/********************************************************
 * Build the Nominations endpoint URL
 ********************************************************/
function committee_nominations_get_url($offset = 0, $limit = 20) {
    $api_key = congress_dot_gov_api_key();  // Adjust to however you store/retrieve your API key
	$committee_code = get_option('legislation_committee_code');
    // Base URL for the committee's nominations
    // Example: https://api.congress.gov/v3/committee/senate/ssga00/nominations?offset=0&limit=20
    $base = "https://api.congress.gov/v3/committee/senate/" . $committee_code . "/nominations"
          . "?offset={$offset}"
          . "&limit={$limit}";

    // Now ensure we add format=json and api_key
    $url = committee_nominations_ensure_format_and_api_key($base, $api_key);
    return $url;
}

/********************************************************
 * Main Display Function (Shortcode Callback)
 ********************************************************/
function display_committee_nominations() {
    ob_start();

    // 1) Determine pagination (using nom_page instead of page)
    $page   = isset($_GET['nom_page']) ? max(1, (int)$_GET['nom_page']) : 1;
    $limit  = 20;
    $offset = ($page - 1) * $limit;

    // 2) Fetch nominations data
    $nomsUrl  = committee_nominations_get_url($offset, $limit);
    $nomsData = committee_nominations_fetch_json($nomsUrl);

    // Check if we have data
    if (!$nomsData || empty($nomsData['nominations'])) {
        echo '<p>No nominations data found.</p>';
        return ob_get_clean();
    }

    // We'll also look for "pagination.count" or something similar.
    $totalCount = !empty($nomsData['pagination']['count']) ? (int)$nomsData['pagination']['count'] : 0;
    $totalPages = ($totalCount > 0) ? ceil($totalCount / $limit) : 1;

    // Each item in "nominations" has "description", "latestAction", etc.
    $nominations = $nomsData['nominations'];
    $results = [];

    foreach ($nominations as $nom) {
        // Action date in first column
        $actionDate = '';
        if (!empty($nom['latestAction']['actionDate'])) {
            $actionDate = $nom['latestAction']['actionDate'];
        }

        // Second column has description + latestAction text
        $description = !empty($nom['description']) ? $nom['description'] : '';
        $actionText  = !empty($nom['latestAction']['text']) ? $nom['latestAction']['text'] : '';

        // Store in $results
        $results[] = [
            'actionDate'   => $actionDate,
            'description'  => $description,
            'actionText'   => $actionText
        ];
    }

    // 3) Output: Table (Desktop) + Cards (Mobile)
    echo '<div class="committee_nominations_table_wrapper committee_desktop_view">';
    echo '<table class="committee_nominations_table">';
    echo '<tr>
            <th>Action&nbsp;Date</th>
            <th>Description / Latest Action</th>
          </tr>';

    foreach ($results as $row) {
        echo '<tr>
                <td valign="top" class="nominations_date_cell">'
                     . htmlspecialchars($row['actionDate']) .
                '</td>
                <td>
                    <div class="committee_nominations_card_row"><strong>Description:</strong> ' . htmlspecialchars($row['description']) . '</div>
                    <div class="committee_nominations_card_row"><strong>Latest Action:</strong> ' . htmlspecialchars($row['actionText']) . '</div>
                </td>
              </tr>';
    }
    echo '</table></div>';

    // Mobile Cards
    echo '<div class="committee_nominations_cards_container committee_mobile_view">';
    foreach ($results as $row) {
        echo '<div class="committee_nominations_card">
                <div class="committee_nominations_card_row">
                    <label>Latest&nbsp;Action:</label>
                    <span>' . htmlspecialchars($row['actionDate']) . '</span>
                </div>
                <div class="committee_nominations_card_row">
                    <label>Description:</label>
                    <span>' . htmlspecialchars($row['description']) . '</span>
                </div>
                <div class="committee_nominations_card_row">
                    <label>Latest Action:</label>
                    <span>' . htmlspecialchars($row['actionText']) . '</span>
                </div>
              </div>';
    }
    echo '</div>';

    // 4) Truncated Pagination (using nom_page)
    committee_nominations_display_truncated_pagination($page, $totalPages, 5);

    return ob_get_clean();
}
