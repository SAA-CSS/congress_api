<?php
/**
 * Plugin Name: Legislative data
 * Description: Provides the Votes and Legislation shortcodes
 * Version: 1.0.5
 */


// Define constants for the update server and plugin slug
define('PLUGIN_UPDATE_URL', 'https://raw.githubusercontent.com/SAA-CSS/congress_api/main/update.json');
define('PLUGIN_SLUG', 'legislative-data/legislative-data.php');

// Hook into the 'pre_set_site_transient_update_plugins' filter
add_filter('pre_set_site_transient_update_plugins', 'check_for_plugin_update');

if (!function_exists('check_for_plugin_update')) {
    function check_for_plugin_update($transient) {
        // Debugging information
        error_log('Checking for plugin update...');

        // Get the current version
        $current_version = '1.0.5';

        // Get the update data from the server
        $response = wp_remote_get(PLUGIN_UPDATE_URL);
        if (is_wp_error($response)) {
            error_log('Error fetching update data: ' . $response->get_error_message());
            return $transient;
        }

        $update_data = wp_remote_retrieve_body($response);
        if (empty($update_data)) {
            error_log('Update data is empty.');
            return $transient;
        }

        $update_data = json_decode($update_data, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('Error decoding JSON: ' . json_last_error_msg());
            return $transient;
        }

        if (empty($update_data['version']) || empty($update_data['download_url'])) {
            error_log('Update data is missing required fields.');
            return $transient;
        }

        // Check if a new version is available
        if (version_compare($current_version, $update_data['version'], '<')) {
            $obj = new stdClass();
            $obj->slug = PLUGIN_SLUG;
            $obj->new_version = $update_data['version'];
            $obj->url = 'https://example.com'; // URL to your plugin page
            $obj->package = $update_data['download_url'];
            $transient->response[PLUGIN_SLUG] = $obj;

            // Debugging information
            error_log('New version available: ' . $update_data['version']);
        } else {
            // Debugging information
            error_log('No new version available. Current version: ' . $current_version . ', Latest version: ' . $update_data['version']);
        }

        return $transient;
    }
}

// Hook into the 'plugins_api' filter to provide information about the update
add_filter('plugins_api', 'plugin_update_info', 10, 3);

if (!function_exists('plugin_update_info')) {
    function plugin_update_info($res, $action, $args) {
        // Ensure it's our plugin being requested
        if ($action !== 'plugin_information' || $args->slug !== 'legislative-data') {
            return false;
        }

        // Debugging information
        error_log('Providing plugin update information...');

        // Get the update data from the server
        $response = wp_remote_get(PLUGIN_UPDATE_URL);
        if (is_wp_error($response)) {
            error_log('Error fetching update data: ' . $response->get_error_message());
            return false;
        }

        $update_data = wp_remote_retrieve_body($response);
        if (empty($update_data)) {
            error_log('Update data is empty.');
            return false;
        }

        $update_data = json_decode($update_data, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('Error decoding JSON: ' . json_last_error_msg());
            return false;
        }

        if (empty($update_data['version']) || empty($update_data['download_url'])) {
            error_log('Update data is missing required fields.');
            return false;
        }

        $res = new stdClass();
        $res->name = 'Legislative Data';
        $res->slug = 'legislative-data';
        $res->version = $update_data['version'];
        $res->author = '<a href="https://example.com">Your Name</a>';
        $res->homepage = 'https://example.com';
        $res->download_link = $update_data['download_url'];
        $res->trunk = $update_data['download_url'];
        $res->requires = '5.0'; // Minimum WordPress version required
        $res->tested = '5.7'; // Tested up to WordPress version
        $res->sections = array(
            'description' => 'A custom plugin for managing legislative data updates.',
            'changelog' => $update_data['changelog']
        );

        return $res;
    }
}




// Register the admin menu
add_action('admin_menu', 'legislation_admin_menu');
function legislation_admin_menu() {
    add_options_page(
        'Legislation Settings',
        'Legislation',
        'manage_options',
        'senate-votes-settings',
        'legislation_settings_page'
    );
}

// Settings page content
function legislation_settings_page() {
    ?>
    <div class="wrap">
        <h1>Senate Votes Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('legislation_settings_group');
            do_settings_sections('senate-votes-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Register settings
add_action('admin_init', 'legislation_register_settings');
function legislation_register_settings() {
    register_setting('legislation_settings_group', 'legislation_lis_member_id');
    register_setting('legislation_settings_group', 'legislation_memberId');
    register_setting('legislation_settings_group', 'congress_dot_gov_api_key'); // Register new setting

    add_settings_section('legislation_settings_section', 'Select Senator', null, 'senate-votes-settings');

    add_settings_field(
        'legislation_senator_select',
        'Senator',
        'legislation_senator_select_callback',
        'senate-votes-settings',
        'legislation_settings_section'
    );

    add_settings_field(
        'congress_dot_gov_api_key_field', // Field ID
        'Congress.gov API Key', // Field Title
        'congress_dot_gov_api_key_callback', // Callback Function
        'senate-votes-settings', // Page
        'legislation_settings_section' // Section
    );
}

// Callback function to display the text field
function congress_dot_gov_api_key_callback() {
    $api_key = congress_dot_gov_api_key();
    echo '<input type="text" id="congress_dot_gov_api_key" name="congress_dot_gov_api_key" value="' . esc_attr($api_key) . '" /> Get your API key here: <a href="https://api.congress.gov/sign-up/" target="_blank">https://api.congress.gov/sign-up/</a>';
}

function set_lis_from_bioguide_id(){
	$xml = @simplexml_load_file('https://www.senate.gov/legislative/LIS_MEMBER/cvc_member_data.xml');
	$memberId = get_option('legislation_memberId');
    $senators = [];
    foreach ($xml->senator as $senator) {
       
        if($senator->bioguideId == $memberId){
			$lis_member_id = (string) $senator['lis_member_id'];
			$api_key = congress_dot_gov_api_key();
			update_option( 'legislation_lis_member_id', $lis_member_id );
			update_option( 'congress_dot_gov_api_key', $api_key );
		}
        
       
    }
}

// Senator select field callback
function legislation_senator_select_callback() {
    $xml = @simplexml_load_file('https://www.senate.gov/legislative/LIS_MEMBER/cvc_member_data.xml');
    if ($xml === false) {
        echo 'Error loading XML file.';
        foreach (libxml_get_errors() as $error) {
            echo "<br>", htmlentities($error->message);
        }
        return;
    }

    $senators = [];
    foreach ($xml->senator as $senator) {
        $lis_member_id = (string) $senator['lis_member_id'];
        $memberId = (string) $senator->bioguideId;
        $first_name = (string) $senator->name->first;
        $last_name = (string) $senator->name->last;
        $full_name = "$last_name, $first_name";
        $senators[] = [
            'lis_member_id' => $lis_member_id,
            'memberId' => $memberId,
            'full_name' => $full_name
        ];
    }

    // Sort senators by full_name
    usort($senators, function ($a, $b) {
        return strcmp($a['full_name'], $b['full_name']);
    });

    echo '<select name="legislation_lis_member_id">';
    foreach ($senators as $senator) {
        $lis_member_id = $senator['lis_member_id'];
        $memberId = $senator['memberId'];
        $full_name = $senator['full_name'];
        $selected = (get_option('legislation_lis_member_id') == $lis_member_id) ? 'selected' : '';
        echo "<option value='$lis_member_id' data-member-id='$memberId' $selected>$full_name</option>";
    }
    echo '</select>';
    echo '<input type="hidden" id="legislation_memberId" name="legislation_memberId" value="' . get_option('legislation_memberId') . '" />';
	
}

// Update hidden input when select box changes
add_action('admin_footer', 'legislation_admin_footer_script');
function legislation_admin_footer_script() {
    ?>
    <script>
        document.querySelector('select[name="legislation_lis_member_id"]').addEventListener('change', function () {
            var selectedOption = this.options[this.selectedIndex];
            document.getElementById('legislation_memberId').value = selectedOption.getAttribute('data-member-id');
        });
    </script>
    <?php
}
//Return the api.congress.gov key
function congress_dot_gov_api_key() {
	$congress_dot_gov_api_key = get_option('congress_dot_gov_api_key');

	return $congress_dot_gov_api_key;
}
// Function to get member terms
function get_member_terms() {
    $memberId = get_option('legislation_memberId');  
    $congress_api_key = congress_dot_gov_api_key(); 
    $url = "https://api.congress.gov/v3/member/$memberId?format=json&API_KEY=$congress_api_key";
    $response = wp_remote_get($url);
    if (is_wp_error($response)) {
        return [];
    }
    $data = json_decode(wp_remote_retrieve_body($response), true);
    $member = $data['member'];
    $member_terms = $member['terms'];
    return $member_terms; 
}

// Enqueue plugin styles
add_action('wp_enqueue_scripts', 'legislation_enqueue_styles');
function legislation_enqueue_styles() {
    wp_enqueue_style('legislation-votes-style', plugins_url('style.css', __FILE__));
}

// Register the shortcode
add_shortcode('votes', 'display_senate_votes');

function display_senate_votes() {
    ob_start();

    $lis_member_id = get_option('legislation_lis_member_id');
    $memberId = get_option('legislation_memberId');

    if (!$lis_member_id) {
		if (!$memberId) {
        echo '<p>Please select a Senator in the plugin settings.</p>';
		} else {
			set_lis_from_bioguide_id();
		}
        return ob_get_clean();
    }

    // Get the member terms
    $terms = get_member_terms();
    if (empty($terms)) {
        echo '<p>No terms found for the selected Senator.</p>';
        return ob_get_clean();
    }

    $selected_year = isset($_GET['vote_year']) ? (int)$_GET['vote_year'] : null;
    $current_year = (int)date("Y");
    $vote_page = isset($_GET['vote_page']) ? (int)$_GET['vote_page'] : 1;
    $votes_per_page = 10;

    // Sort the terms by year in descending order
    usort($terms, function ($a, $b) {
        return $b['startYear'] - $a['startYear'];
    });

    // Display the select box for congressional terms
echo '<div class="legislation-votes-form-wrapper">';
echo '<form method="get" class="legislation-votes-form">';
echo '<label for="vote_year">Year: </label>';
echo '<select name="vote_year" id="vote_year" onchange="this.form.submit()">';
foreach ($terms as $term) {
    if ($term['chamber'] === 'Senate') {
        $startYear = $term['startYear'];
        $startYearPlusOne = $startYear + 1;

        $selected_attr_1 = ($startYear == $selected_year) ? 'selected' : '';
        $selected_attr_2 = ($startYearPlusOne == $selected_year) ? 'selected' : '';

        if ($startYear != $current_year) {    
            echo '<option value="' . $startYearPlusOne . '"' . $selected_attr_2 . '> ' . $startYearPlusOne . ' (Congress ' . $term['congress'] . ' Session 2)</option>';
        }
        echo '<option value="' . $startYear . '" ' . $selected_attr_1 . '>' . $startYear . ' (Congress ' . $term['congress'] . ' Session 1)</option>';
    }
}
echo '</select>';
//echo '<input type="submit" value="Go">';
echo '</form>';
echo '</div>';

// Display the table (same as before)


    if (!$selected_year) {
        $selected_year = $current_year;
    }

    $congress_number = floor(($selected_year - 1789) / 2) + 1;
    $session = ($selected_year % 2 === 0) ? 2 : 1;
    $year = "{$congress_number}_{$session}";

    $votes = [];
    $found_votes = 0;
    $max_votes_to_find = $votes_per_page;
    $offset = ($vote_page - 1) * $votes_per_page;

    // Fetch the vote menu XML to get the list of recent votes
    $menu_url = "https://www.senate.gov/legislative/LIS/roll_call_lists/vote_menu_{$year}.xml";

    // Use cURL to fetch the XML file
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $menu_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_FAILONERROR, true); // to get HTTP errors in curl_error
    $menu_xml_content = curl_exec($ch);
    curl_close($ch);

    if ($menu_xml_content === false) {
        echo 'Error loading votes menu XML file: ' . htmlentities($menu_url) . '<br>';
        return ob_get_clean();
    }

    

    // Load the XML content
    libxml_use_internal_errors(true);
    $menu_xml = @simplexml_load_string($menu_xml_content);
    if ($menu_xml === false) {
        echo 'Error parsing votes menu XML file: ' . htmlentities($menu_url) . '<br>';
        foreach (libxml_get_errors() as $error) {
            echo htmlentities($error->message) . '<br>';
        }
        return ob_get_clean();
    }

    // Iterate over the votes listed in the menu XML
    $total_votes = count($menu_xml->votes->vote);
    $start = $offset;
    $end = $start + $votes_per_page;

    for ($i = $start; $i < $end && $i < $total_votes; $i++) {
        $vote = $menu_xml->votes->vote[$i];
        $vote_number = (string) $vote->vote_number;
        $vote_date = (string) $vote->vote_date;
        $vote_date = date('m-d-Y', strtotime($vote_date . ' ' . $selected_year)); // Convert to mm-dd-yyyy format
        $title = (string) $vote->title;
        $question = (string) $vote->question;
        $result = (string) $vote->result;
        $yeas = (int) $vote->vote_tally->yeas;
        $nays = (int) $vote->vote_tally->nays;
        $summary_html = "https://www.senate.gov/legislative/LIS/roll_call_votes/vote{$congress_number}{$session}/vote_{$congress_number}_{$session}_$vote_number.htm";
        $vote_url = "https://www.senate.gov/legislative/LIS/roll_call_votes/vote{$congress_number}{$session}/vote_{$congress_number}_{$session}_$vote_number.xml";

        // Use cURL to fetch the vote detail XML file
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $vote_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_FAILONERROR, true); // to get HTTP errors in curl_error
        $vote_xml_content = curl_exec($ch);
        curl_close($ch);

        if ($vote_xml_content === false) {
            continue; // Skip this vote if it can't be loaded
        }

        libxml_use_internal_errors(true);
        $vote_xml = @simplexml_load_string($vote_xml_content);
        if ($vote_xml === false) {
            continue; // Skip this vote if it can't be parsed
        }

        $my_vote = 'N/A';
        foreach ($vote_xml->members->member as $member) {
            if ((string) $member->lis_member_id == $lis_member_id) {
                $my_vote = (string) $member->vote_cast;
                break;
            }
        }

        $votes[] = [
            'date' => $vote_date,
            'description' => $title,
            'question' => $question,
            'result' => $result,
            'yeas' => $yeas,
            'nays' => $nays,
            'my_vote' => $my_vote,
            'summary_html' => $summary_html
        ];
    }

    // Display the table
    echo '<table class="vote_table">';
    echo '<tr>';
    echo '<th class="legislation_table_th vote_date_th">Vote&nbsp;Date</th>';
    echo '<th class="legislation_table_th vote_description_th">Description</th>';
    echo '<th class="legislation_table_th vote_myvote_th">My&nbsp;Vote</th>';
    echo '<th class="legislation_table_th vote_result_th">Vote&nbsp;Result</th>';
    
    echo '</tr>';
    foreach ($votes as $vote) {
		$vote_tally = $vote['yeas'] + $vote['nays'];
    	$yeas_percentage = ($vote_tally > 0) ? ($vote['yeas'] / $vote_tally) * 100 : 0;
    	$nays_percentage = 100 - $yeas_percentage;
        echo '<tr>';
        echo '<td class="vote_date_column"><span class="legislation_date">' . htmlentities($vote['date']) . '</span></td>';
        echo '<td class="vote_detail"><div class="vote_question">' . htmlspecialchars($vote['question']) . '</div><div class="vote_title">' . htmlspecialchars($vote['description']) . '</div><div class="vote_link"><a href="' . htmlspecialchars($vote['summary_html']) . '" target="_blank">Vote Details</a></div></td>';
        echo '<td class="vote_position">' . htmlspecialchars($vote['my_vote']) . '</td>';
        echo '<td class="vote_result_column"><div class="vote_result">' . htmlspecialchars($vote['result']) . '</div><div class="vote_yeanay">(Y:' . htmlspecialchars($vote['yeas']) . ' N:' . htmlspecialchars($vote['nays']) . ')</div>';
		echo '<div class="vote_tally_container">';
		echo '<div class="vote_tally_yeas" style="width:' . $yeas_percentage . '%;"></div>';
		echo '<div class="vote_tally_nays" style="width:' . $nays_percentage . '%;"></div>';
		echo '</div>';
		echo '</td>';
        
        echo '</tr>';
    }
    echo '</table>';

  
	  
	
	
// Display pagination
$total_pages = ceil($total_votes / $votes_per_page);
$max_display_pages = 5; // Number of page numbers to display

if ($total_pages > 1) {
    echo '<div class="votes_pagination_container">';
    
    if ($vote_page > 1) {
        $prevpage = $vote_page - 1;
        echo '<span class="page_prev vote_page_prev"><a href="?vote_year=' . $selected_year . '&vote_page=' . $prevpage . '">&#171;</a></span>';
    }

    // Special case for first page
    if ($vote_page == 1) {
        echo '<span class="votes_page_number votes_page_number_active">1</span>';
        for ($i = 2; $i <= min(3, $total_pages); $i++) {
            echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=' . $i . '">' . $i . '</a></span>';
        }
        if ($total_pages > 3) {
            echo '<span class="ellipsis">...</span>';
            echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=' . $total_pages . '">' . $total_pages . '</a></span>';
        }
    } 

    // Special case for last page
    elseif ($vote_page == $total_pages) {
        if ($total_pages > 3) {
            echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=1">1</a></span>';
            echo '<span class="ellipsis">...</span>';
        }
        for ($i = max(1, $total_pages - 2); $i < $total_pages; $i++) {
            echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=' . $i . '">' . $i . '</a></span>';
        }
        echo '<span class="votes_page_number votes_page_number_active">' . $total_pages . '</span>';
    } 

    // General case
    else {
        // Show first page
        echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=1">1</a></span>';
        
        if ($vote_page > 4) {
            echo '<span class="ellipsis">...</span>';
        }

        // Calculate start and end of range
        $start = max(2, $vote_page - 2);
        $end = min($total_pages - 1, $vote_page + 2);

        for ($i = $start; $i <= $end; $i++) {
            if ($i == $vote_page) {
                echo '<span class="votes_page_number votes_page_number_active">' . $i . '</span>';
            } else {
                echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=' . $i . '">' . $i . '</a></span>';
            }
        }

        if ($vote_page < $total_pages - 3) {
            echo '<span class="ellipsis">...</span>';
        }

        // Show last page
        echo '<span class="votes_page_number"><a href="?vote_year=' . $selected_year . '&vote_page=' . $total_pages . '">' . $total_pages . '</a></span>';
    }

    if ($vote_page < $total_pages) {
        $nextpage = $vote_page + 1;
        echo '<span class="page_next vote_page_next"><a href="?vote_year=' . $selected_year . '&vote_page=' . $nextpage . '">&#187;</a></span>';
    }

    echo '</div>';
}



    return ob_get_clean();
}


// Register the shortcode
add_shortcode('legislation', 'display_legislation');

function display_legislation() {
    ob_start();

    $lis_member_id = get_option('legislation_lis_member_id');
    $memberId = get_option('legislation_memberId');

    if (!$lis_member_id) {
		if (!$memberId) {
        echo '<p>Please select a Senator in the plugin settings.</p>';
		} else {
			set_lis_from_bioguide_id();
		}
        return ob_get_clean();
    }

    $congress_api_key = congress_dot_gov_api_key();
    $leg_type = isset($_GET['leg_type']) ? $_GET['leg_type'] : 'sponsored';
    $page = isset($_GET['leg_page']) ? (int)$_GET['leg_page'] : 1;
    $items_per_page = 20;
    $offset = ($page - 1) * $items_per_page;

    // Function to fetch update date from bill detail endpoint
    function fetch_update_date($url, $congress_api_key) {
        $response = wp_remote_get($url . '?format=json&api_key=' . $congress_api_key);
        if (is_wp_error($response)) {
            return null;
        }
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        return isset($data['bill']['updateDate']) ? $data['bill']['updateDate'] : null;
    }

    // Determine the endpoint based on the selected type
    $endpoint = $leg_type === 'cosponsored' ? 'cosponsored-legislation' : 'sponsored-legislation';
    $api_url = "https://api.congress.gov/v3/member/$memberId/$endpoint?format=json&api_key=$congress_api_key&limit=$items_per_page&offset=$offset";

    // Fetch legislation data
    $response = wp_remote_get($api_url);
    if (is_wp_error($response)) {
        echo '<p>Error fetching legislation data.</p>';
        echo '<p>' . $response->get_error_message() . '</p>';
        return ob_get_clean();
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    if (!$data || (!isset($data['sponsoredLegislation']) && !isset($data['cosponsoredLegislation']))) {
        echo '<p>No legislation data found.</p>';
        echo '<!-- Debugging: ' . htmlentities($body) . ' -->';
        return ob_get_clean();
    }

    // Extract the relevant data
    $legislation_data = isset($data['sponsoredLegislation']) ? $data['sponsoredLegislation'] : $data['cosponsoredLegislation'];

    // Extract pagination info
    $total_items = $data['pagination']['count'];
    $total_pages = ceil($total_items / $items_per_page);

    // Filter and sort the data by latest activity date
    $filtered_data = array_filter($legislation_data, function($item) {
        return $item['type'] === 'HR' || $item['type'] === 'S';
    });

    // Fetch update dates and sort by update date
    foreach ($filtered_data as &$item) {
        $update_date = fetch_update_date($item['url'], $congress_api_key);
        $item['updateDate'] = $update_date;
    }
    unset($item); // Break reference to the last element

    usort($filtered_data, function ($a, $b) {
        return strtotime($b['updateDate']) - strtotime($a['updateDate']);
    });

    // Function to format the date to mm-dd-yyyy
    function format_date($date) {
        if (!$date) {
            return '';
        }
        $timestamp = strtotime($date);
        return date('m-d-Y', $timestamp);
    }

    // Function to generate the correct Congress.gov URL
    function generate_congress_gov_url($congress, $type, $number) {
        $chamber = ($type == 'HR') ? 'house-bill' : 'senate-bill';
        return "https://www.congress.gov/bill/{$congress}th-congress/{$chamber}/{$number}";
    }

    // Display the form for toggling between Sponsored and Cosponsored legislation
    echo '<div class="legislation-votes-form-wrapper">';
    echo '<form method="get" id="legislation-toggle-form" class="legislation-votes-form">';
    echo '<label>Type: </label>';
    echo '<select name="leg_type" onchange="this.form.submit()">';
    echo '<option value="sponsored"' . ($leg_type === 'sponsored' ? ' selected' : '') . '>Sponsored legislation</option>';
    echo '<option value="cosponsored"' . ($leg_type === 'cosponsored' ? ' selected' : '') . '>Cosponsored legislation</option>';
    echo '</select>';
    echo '</form>';
    echo '</div>';

    // Display the table
    echo '<table class="legislation-table">';
    echo '
	<thead>
	<tr>
	<th class="legislation_table_th legislation_update_th">Updated</th>
	<th class="legislation_table_th legislation_overview_th">Bill Information</th>
	<th class="legislation_table_th legislation_link_th">Detail</th>
	</tr>
	</thead>';
    echo '<tbody>';
    foreach ($filtered_data as $item) {
        $title = $item['title'];
        $bill_type = $item['type'];
        $number = $item['number'];
        $introduced_date = $item['introducedDate'];
        $latest_action_text = isset($item['latestAction']['text']) ? $item['latestAction']['text'] : '';
        $congress_gov_url = generate_congress_gov_url($item['congress'], $bill_type, $number);

        // Fetch the update date from the detail endpoint
        $update_date = isset($item['updateDate']) ? $item['updateDate'] : '';
        $formatted_update_date = format_date($update_date);

        echo '<tr>';
        echo '<td class="legislation_update_column">';
		echo '<div class="legislation_update_date legislation_date">' . esc_html($formatted_update_date) . '</div>';
		echo '</td>';
		
        echo '<td  class="legislation_title_column">';
		
		echo '<div class="legislation_title"><em><a href="' . esc_url($congress_gov_url) . '" target="_blank">' . esc_html($bill_type . '.' . $number) . '</em></a> | ' . esc_html($title) . '</div>';
		echo '<div class="legislation_introduced_date"><em>Introduced:</em> <span class="legislation_date">' . esc_html(format_date($introduced_date)) . '</span></div>';
		echo '<div class="legislation_latest_action"><em>Latest Action:</em> ' . esc_html($latest_action_text) . '</div>';
		echo '</td>';
        echo '<td class="legislation_link_column">';
		echo '<div class="legislation_link"><a href="' . esc_url($congress_gov_url) . '" target="_blank">Detail</a></div>';
		
		echo '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';

    // Pagination links
    if ($total_pages > 1) {
        echo '<div class="votes_pagination_container">';
        if ($page > 1) {
            $prev_page = $page - 1;
            echo '<span class="page_prev vote_page_prev"><a href="?leg_type=' . $leg_type . '&leg_page=' . $prev_page . '">&laquo;</a></span>';
        }

        $range = 2;
        $start = max(1, $page - $range);
        $end = min($total_pages, $page + $range);

        if ($start > 1) {
            echo '<span class="votes_page_number"><a href="?leg_type=' . $leg_type . '&leg_page=1">1</a></span>';
            if ($start > 2) {
                echo '<span class="ellipsis">...</span>';
            }
        }

        for ($i = $start; $i <= $end; $i++) {
            if ($i == $page) {
                echo '<span class="votes_page_number votes_page_number_active">' . $i . '</span>';
            } else {
                echo '<span class="votes_page_number"><a href="?leg_type=' . $leg_type . '&leg_page=' . $i . '">' . $i . '</a></span>';
            }
        }

        if ($end < $total_pages) {
            if ($end < $total_pages - 1) {
                echo '<span class="ellipsis">...</span>';
            }
            echo '<span class="votes_page_number"><a href="?leg_type=' . $leg_type . '&leg_page=' . $total_pages . '">' . $total_pages . '</a></span>';
        }

        if ($page < $total_pages) {
            $next_page = $page + 1;
            echo '<span class="page_next vote_page_next"><a href="?leg_type=' . $leg_type . '&leg_page=' . $next_page . '">&raquo;</a></span>';
        }
        echo '</div>';
    }

    return ob_get_clean();
}



?>
